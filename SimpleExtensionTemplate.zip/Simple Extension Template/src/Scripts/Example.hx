package scripts;

import com.stencyl.Engine;

class Example
{
	public static var example:String = "HelloWorld!";

	public static function exampleGetter():String{
		return example;
	}

	public static function exampleSetter(e:String):Void{
		example = e;
	}
}